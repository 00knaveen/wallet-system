<div class="list-group">

    <a href="<?php echo e(url('/')); ?>"
       class="list-group-item">

        Dashboard

    </a>

    <a href="<?php echo e(url('/wallet/balance')); ?>"
       class="list-group-item">

        Balance

    </a>

    <a href="<?php echo e(url('/wallet/history')); ?>"
       class="list-group-item">

        History

    </a>

</div><?php /**PATH C:\xampp\htdocs\wallet-system\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>