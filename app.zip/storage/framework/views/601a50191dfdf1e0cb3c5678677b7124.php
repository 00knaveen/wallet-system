<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<title>Wallet System</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><?php /**PATH C:\xampp\htdocs\wallet-system\resources\views/layouts/header.blade.php ENDPATH**/ ?>