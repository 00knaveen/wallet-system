<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<?php echo $__env->yieldPushContent('scripts'); ?><?php /**PATH C:\xampp\htdocs\wallet-system\resources\views/layouts/footer.blade.php ENDPATH**/ ?>