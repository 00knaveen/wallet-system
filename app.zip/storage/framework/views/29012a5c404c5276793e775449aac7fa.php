<nav class="navbar navbar-dark bg-dark">

    <div class="container-fluid">

        <span class="navbar-brand">

            High Concurrency Wallet System

        </span>

    </div>

</nav><?php /**PATH C:\xampp\htdocs\wallet-system\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>