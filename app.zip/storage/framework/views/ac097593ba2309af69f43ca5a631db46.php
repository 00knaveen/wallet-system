

<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <div class="card shadow">

        <div class="card-header bg-primary text-white">

            <h4 class="mb-0">
                Wallet Balance
            </h4>

        </div>

        <div class="card-body">

            <div class="row mb-3">

                <div class="col-md-4">

                    <input type="text"
                           class="form-control"
                           id="search"
                           placeholder="Search User">

                </div>

            </div>

            <table class="table table-bordered table-striped table-hover">

                <thead class="table-dark">

                <tr>

                    <th>#</th>

                    <th>User</th>

                    <th>Wallet ID</th>

                    <th>Balance</th>

                    <th>Version</th>

                    <th>Status</th>

                </tr>

                </thead>

                <tbody>

                <?php $__empty_1 = true; $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <tr>

                        <td><?php echo e($key + 1); ?></td>

                        <td><?php echo e($wallet->name); ?></td>

                        <td><?php echo e($wallet->id); ?></td>

                        <td>

                            ₹ <?php echo e(number_format($wallet->balance,2)); ?>


                        </td>

                        <td>

                            <?php echo e($wallet->version); ?>


                        </td>

                        <td>

                            <?php if($wallet->balance > 0): ?>

                                <span class="badge bg-success">

                                    Active

                                </span>

                            <?php else: ?>

                                <span class="badge bg-danger">

                                    Empty

                                </span>

                            <?php endif; ?>

                        </td>

                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <tr>

                        <td colspan="6" class="text-center">

                            No Wallet Found

                        </td>

                    </tr>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<script>

$('#search').on('keyup', function () {

    var value = $(this).val().toLowerCase();

    $("table tbody tr").filter(function () {

        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);

    });

});

</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\wallet-system\resources\views/wallet/balance.blade.php ENDPATH**/ ?>