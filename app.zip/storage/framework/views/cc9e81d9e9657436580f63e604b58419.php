

<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <div class="card shadow">

        <div class="card-header bg-primary text-white d-flex justify-content-between">

            <h4 class="mb-0">
                Wallet Transaction History
            </h4>

            <input
                type="text"
                id="search"
                class="form-control w-25"
                placeholder="Search...">

        </div>

        <div class="card-body">

            <div class="table-responsive">

                <table class="table table-bordered table-hover align-middle">

                    <thead class="table-dark">

                    <tr>

                        <th>#</th>
                        <th>Reference No</th>
                        <th>Sender</th>
                        <th>Receiver</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Date</th>

                    </tr>

                    </thead>

                    <tbody>

                    <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <tr>

                            <td><?php echo e($transactions->firstItem()+$key); ?></td>

                            <td>

                                <span class="badge bg-secondary">

                                    <?php echo e($transaction->reference_no); ?>


                                </span>

                            </td>

                            <td>

                                <?php echo e($transaction->sender_name); ?>


                            </td>

                            <td>

                                <?php echo e($transaction->receiver_name); ?>


                            </td>

                            <td>

                                ₹ <?php echo e(number_format($transaction->amount,2)); ?>


                            </td>

                            <td>

                                <?php if($transaction->status=="completed"): ?>

                                    <span class="badge bg-success">

                                        Completed

                                    </span>

                                <?php elseif($transaction->status=="pending"): ?>

                                    <span class="badge bg-warning">

                                        Pending

                                    </span>

                                <?php else: ?>

                                    <span class="badge bg-danger">

                                        Failed

                                    </span>

                                <?php endif; ?>

                            </td>

                            <td>

                                <?php echo e(date('d-m-Y h:i A',strtotime($transaction->created_at))); ?>


                            </td>

                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <tr>

                            <td colspan="7" class="text-center">

                                No Transactions Found

                            </td>

                        </tr>

                    <?php endif; ?>

                    </tbody>

                </table>

            </div>

            <div class="mt-3">

                <?php echo e($transactions->links()); ?>


            </div>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<script>

document.getElementById('search').addEventListener('keyup', function(){

    let value=this.value.toLowerCase();

    document.querySelectorAll("tbody tr").forEach(function(row){

        row.style.display=row.innerText.toLowerCase().includes(value)
            ? ""
            : "none";

    });

});

</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\wallet-system\resources\views/wallet/history.blade.php ENDPATH**/ ?>